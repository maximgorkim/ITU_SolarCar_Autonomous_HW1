#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
using namespace std::chrono_literals;

class KeyboardTeleop : public rclcpp::Node {
public:
  KeyboardTeleop() : Node("keyboard_step1") {
    pub_ = create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel", 10);

    // terminal: raw + nonblocking
    tcgetattr(STDIN_FILENO, &orig_);
    termios raw = orig_;
    raw.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &raw);
    int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);

    // 50 Hz yayın: tuşa basmasan da son komut korunur
    timer_ = create_wall_timer(20ms, [this](){ pub_->publish(cmd_); });

    RCLCPP_INFO(get_logger(), "Controls: w/s forward-back, a/d turn, SPACE stop");
  }

  ~KeyboardTeleop(){ tcsetattr(STDIN_FILENO, TCSANOW, &orig_); }

  void spin_once(){
    char c;
    if (read(STDIN_FILENO, &c, 1) > 0){
      switch (c){
        case 'w': cmd_.linear.x = 1.5; break;
        case 's': cmd_.linear.x = -1.0; break;
        case 'a': cmd_.angular.z = 1.8; break;
        case 'd': cmd_.angular.z = -1.8; break;
        case ' ': cmd_.linear.x = 0.0; cmd_.angular.z = 0.0; break;
        default: break;
      }
    }
    rclcpp::sleep_for(5ms); // CPU'yu yorma
  }

private:
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr pub_;
  rclcpp::TimerBase::SharedPtr timer_;
  geometry_msgs::msg::Twist cmd_;
  termios orig_;
};

int main(int argc, char** argv){
  rclcpp::init(argc, argv);
  auto node = std::make_shared<KeyboardTeleop>();
  while (rclcpp::ok()){
    rclcpp::spin_some(node);  // timer/callback çalışsın
    node->spin_once();        // varsa bir tuş oku
  }
  rclcpp::shutdown();
  return 0;
}
